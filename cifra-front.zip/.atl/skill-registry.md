# Skill Registry: front_fincompare

This registry documents all the local AI agent skills defined for the `front_fincompare` project.

| Skill File | Title / Topic | Description / Context | Path |
| --- | --- | --- | --- |
| `skill-api-integration.md` | **API Integration — Consumo de Backend Hexagonal** | Defines typescript interfaces mapping Go backend domain models, TanStack React Query cache rules (keys and stale times), versioned contracts (`/api/v1/`), and mocking behavior for testing frontend views. | [.agents/skills/skill-api-integration.md](file:///C:/Users/jpaez/OneDrive/Escritorio/konjunto/front_fincompare/.agents/skills/skill-api-integration.md) |
| `skill-errors.md` | **Errors — Manejo de Errores** | Standards for error management, wrapping in Go backend domain/HTTP layers, client-side React error boundaries, non-intrusive toasts, input validation, and secure context logging. | [.agents/skills/skill-errors.md](file:///C:/Users/jpaez/OneDrive/Escritorio/konjunto/front_fincompare/.agents/skills/skill-errors.md) |
| `skill-finance.md` | **Finance — Lógica de Negocio Financiera** | Calculations for Colombian financial assets (CDT with 15% ReteFuente retention, ETFs with USD to COP TRM mapping, Colombian Stocks) and client-side on-the-fly simulator formatting rules. | [.agents/skills/skill-finance.md](file:///C:/Users/jpaez/OneDrive/Escritorio/konjunto/front_fincompare/.agents/skills/skill-finance.md) |
| `skill-frontend.md` | **Frontend — React & UI/UX** | Front-end tech stack guidelines: React 19 (`useActionState`, `useOptimistic`), Tailwind CSS v4 (`@theme`), Motion animation rules, ECharts/Recharts data visualization, and an "Institutional Terminal" light slate UX pattern. | [.agents/skills/skill-frontend.md](file:///C:/Users/jpaez/OneDrive/Escritorio/konjunto/front_fincompare/.agents/skills/skill-frontend.md) |
