# Skill: Errors — Manejo de Errores

Estándares para la gestión de errores en FinCompare.

## 1. Backend (Go)
- **Tipado:** Definir errores comunes en `internal/domain/errors.go`.
- **Wrapping:** Siempre usar `%w` para mantener la trazabilidad.
- **HTTP:** Mapear errores de dominio a códigos HTTP correctos.

## 2. Frontend (React)
- **Error Boundaries:** Envolver vistas principales para evitar colapsos.
- **Toasts:** Notificaciones no intrusivas para errores de red.
- **Validación:** Validar inputs en el cliente antes de enviar a la API.

## 3. Logs
- No loguear información sensible.
- Incluir contexto (IDs de transacción, parámetros de entrada) en los logs de error.
