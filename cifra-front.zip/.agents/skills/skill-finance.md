# Skill: Finance — Lógica de Negocio Financiera

Esta skill proporciona las reglas para calcular rendimientos, impuestos y comparaciones de activos financieros en el contexto colombiano, sincronizadas con el motor matemático del backend.

## 1. CDTs (Certificados de Depósito a Término)
- **Impuesto:** La retención en la fuente (ReteFuente) sobre rendimientos financieros es estrictamente del **7%** (Estatuto Tributario Art. 395).
- **Liquidación de Impuestos:** Se liquida y deduce el 7% de interés acumulado de manera anual, es decir, al finalizar cada ciclo de 12 meses (meses 12, 24, 36, etc.) y no de forma mensual.
- **Fórmula de Rendimiento Neto:**
  - El interés se compone mensualmente a partir de la tasa efectiva anual (EA).
  - Al mes 12 se deduce la ReteFuente del 7% sobre todo el interés ganado en el año, reinvirtiendo el remanente neto más los aportes recurrentes (DCA).

## 2. Inflación y Retorno Real (Ecuación de Fisher)
- **Ecuación Exacta de Fisher:** Para calcular el valor real y el retorno neto real deflactado de cualquier activo, se aplica la relación exacta de Fisher, no la aproximación lineal:
  $$r_{real} = \frac{1 + r_{nominal}}{1 + i} - 1$$
- **Inflación Mensualizada:** La inflación anual de referencia (5% para COP, 2% para USD) se mensualiza de forma compuesta para calcular el deflactor en la trayectoria mes a mes:
  $$i_{mensual} = (1 + i_{anual})^{1/12} - 1$$
- **Trayectorias Paralelas:** Para cada escenario simulado se calculan y muestran el **Valor Nominal** (saldo bruto proyectado) y el **Valor Real** (poder adquisitivo ajustado).

## 3. Escenarios de Renta Variable (Monte Carlo stochastics)
- **Simulaciones:** Para acciones, ETFs y portafolios diversificados, el simulador corre 10,000 trayectorias de Movimiento Browniano Geométrico (GBM).
- **Percentiles:** Los resultados del backend se agrupan en tres percentiles ordenados que el frontend debe visualizar:
  - **Conservador (P10):** Escenario de bajas ganancias, sirve como límite de protección.
  - **Base (P50):** Mediana de las simulaciones, el camino de retorno más probable.
  - **Optimista (P90):** Escenario con vientos de cola favorables en el mercado.
- **Consistencia:** En todo punto de la trayectoria debe cumplirse estrictamente:
  $$\text{Conservador (P10)} < \text{Base (P50)} < \text{Optimista (P90)}$$

## 4. Conversión TRM (Activos en USD vs Cuentas en COP)
- **Monto Inicial y Aportes:** Si el usuario aporta en COP y el activo cotiza en USD, se convierte el capital usando la TRM actual para la simulación de retornos en USD.
- **Presentación:** Los resultados simulados en USD pueden reconvertirse a COP utilizando la TRM para la visualización en la moneda local del usuario, según su preferencia.

## 5. Citas Bibliográficas y Marco Teórico (Educación)
El frontend debe exponer de manera transparente estas fuentes académicas y regulatorias en la sección didáctica:
1. **Teoría Moderna de Portafolios (MPT) de Harry Markowitz**:
   - Libro guía: *“Portfolio Selection: Efficient Diversification of Investments”* (Markowitz, 1959).
   - Libro académico de referencia: *“Investments”* (Bodie, Kane, Marcus).
   - Concepto: La diversificación reduce el riesgo no sistemático y desplaza la frontera eficiente.
2. **Sharpe Ratio (Rendimiento Ajustado por Riesgo) de William F. Sharpe**:
   - Artículo científico: *“The Sharpe Ratio”* (Sharpe, Journal of Portfolio Management, 1994).
   - Concepto: Exceso de retorno del activo sobre la tasa libre de riesgo por unidad de volatilidad.
3. **Poder Adquisitivo Real (Ecuación de Fisher)**:
   - Libro guía: *“The Theory of Interest”* (Irving Fisher, 1930).
   - Concepto: Relación no lineal exacta entre retorno nominal, real e inflación. Datos basados en el IPC de Colombia (publicado mensualmente por el DANE).
4. **Renta Fija y Garantías en Colombia**:
   - Estatuto Tributario de Colombia, Artículo 395 (Retención en la fuente del 7% sobre intereses).
   - Seguro de depósitos: **Fogafín** (protección hasta $50,000,000 COP para bancos vigilados por la Superintendencia Financiera de Colombia) y **Fogacoop** (protección hasta $32,000,000 COP para cooperativas financieras inscritas).
5. **Certificación de Tipo de Cambio (TRM)**:
   - Certificada y regulada oficialmente por la **Superintendencia Financiera de Colombia (SFC)** basada en el mercado cambiario real.
