# Skill: Frontend — React & UI/UX

Estándares para la interfaz de usuario de FinCompare, orientados al simulador de la Etapa 4.

## 1. Tech Stack
- **React 19:** Utilizar componentes funcionales limpios y hooks reactivos.
- **Tailwind CSS v4:** Usar clases utilitarias de Tailwind v4 y variables CSS nativas para el tema oscuro/claro premium.
- **Motion:** Micro-interacciones suaves en los sliders de entrada y transiciones al cambiar el tipo de activo.

## 2. Componentes de Entrada del Simulador
- **Sliders y Campos de Texto:** Diseñar controles duales (slider + input de texto numérico) y sincronizados para:
  - **Inversión Inicial ($PV$):** Rango de 0 a 100M COP (o 0 a 25k USD).
  - **Aporte Mensual ($PMT$):** Rango de 0 a 10M COP (o 0 a 2.5k USD).
  - **Horizonte de Proyección:** Slider estricto de 1 a 10 años (12 a 120 meses).
- **Selector Nominal vs Real:** Un botón de alternancia o tab para conmutar la visualización del gráfico de Fisher.
- **Valores por defecto en UI:** Cargar dinámicamente según la moneda activa:
  - COP: 10,000,000 PV / 500,000 PMT.
  - USD: 2,500 PV / 125 PMT.

## 3. Visualización y Gráficos (Recharts / ECharts)
- **Componente de Gráfico:** Usar `ResponsiveContainer` de Recharts para gráficos adaptables.
- **Líneas de Escenario:** Renderizar 3 líneas de series temporales de forma clara y armónica:
  - **Conservador (P10):** Línea discontinua o de color más tenue (ej. Slate/Amber).
  - **Base (P50):** Línea principal continua y destacada (ej. Blue/Indigo).
  - **Optimista (P90):** Línea discontinua o de color brillante (ej. Emerald).
- **Abanico Probabilístico:** Para Monte Carlo, usar un componente de área sombreada translúcida (`<Area>` en Recharts) que rellene el espacio entre el escenario Conservador (P10) y el Optimista (P90). Esto representa visualmente el rango de dispersión estocástica.
- **Formateo Numérico:** Todos los montos monetarios en el Tooltip y en el eje Y deben estar formateados en COP o USD según corresponda, utilizando `Intl.NumberFormat`.

## 4. Educación y Transparencia
- **Bloque de Educación:** Renderizar la información de la sección `education` que responde la API en tarjetas de diseño premium ("Institutional Terminal" con bordes finos, fondo oscuro sofisticado y tipografías claras).
- **Explicación Matemática:** Mostrar de forma visual la retención del 7% aplicada anualmente al CDT y el descuento de inflación de la ecuación exacta de Fisher al alternar a "Valor Real".
- **Disclaimers:** Ubicar las advertencias en la base de la pantalla de forma clara pero sutil (especificando Fogafín, Estatuto Tributario y aclarando que "rendimientos pasados no garantizan retornos futuros").
