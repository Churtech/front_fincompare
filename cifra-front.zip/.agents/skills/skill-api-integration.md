# Skill: API Integration — Consumo de Backend Hexagonal

Esta skill define cómo el frontend de FinCompare se comunica con el backend en Go, respetando su arquitectura y los nuevos contratos de simulación.

## 1. Mapeo de Dominio (TypeScript Interfaces)

Deben ser un reflejo exacto de los structs del `internal/domain` del backend. Para el módulo de escenarios probabilísticos de la Etapa 4:

```typescript
export interface ScenarioTrajectoryPoint {
  month: number;
  nominal_value: number;
  real_value: number;
}

export interface Scenario {
  name: string; // "Conservador", "Base", "Optimista"
  return_rate: number; // Tasa nominal de retorno anualizada
  real_return: number; // Tasa de retorno real anualizada (Fisher)
  trajectory: ScenarioTrajectoryPoint[]; // Proyección mensual
}

export interface AnalysisReport {
  metadata: {
    id: string;
    type: string; // "asset" | "portfolio" | "comparison"
    currency: string;
    lookback_days: number;
    formula_version: string;
    calculated_at: string;
  };
  assumptions: {
    risk_free_rate: number;
    inflation_rate: number;
    trm: number;
  };
  scenarios?: Scenario[]; // Escenarios probabilísticos o deterministas
  // ... otros campos como data_quality, risk_analysis, etc.
}
```

## 2. Parámetros de Simulación en Endpoints
- **GET `/api/v1/assets/:ticker/analysis`** y **GET `/api/v1/portfolios/:portfolio_id/analysis`**:
  - Parámetros query opcionales:
    - `initial_amount` (number): Capital inicial ($PV$).
    - `monthly_contribution` (number): Aporte mensual ($PMT$).
    - `projection_years` (number): Horizonte de simulación (1 a 10 años).
- **POST `/api/v1/compare/analysis`**:
  - Cuerpo de petición DTO:
    ```typescript
    export interface CompareAnalysisRequest {
      portfolio_ids: number[];
      currency?: string;
      lookback_days?: number;
      initial_amount?: number;
      monthly_contribution?: number;
      projection_years?: number;
    }
    ```

## 3. React Query (TanStack Query)
- **Keys:** Usar una estructura jerárquica para las Query Keys incluyendo los parámetros de simulación (ej. `['analysis', 'asset', ticker, { initialAmount, monthlyContribution, projectionYears }]`).
- **Stale Time:** Configurar tiempos de expiración realistas. Para análisis históricos e iteraciones de la simulación, usar `staleTime: 1000 * 60 * 15` (15 minutos) para evitar refetching innecesario en renders intermedios de los sliders.

## 4. Manejo de Errores
- Capturar y transformar las respuestas de error del backend (JSON con `error` field) utilizando la infraestructura de toasts o de alertas configurada en `skill-errors`. En especial, manejar errores de validación cuando los inputs del usuario son negativos o superan el horizonte permitido.
