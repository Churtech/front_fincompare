# Workflow: Spec Writer — Diseño y Especificación

Este workflow se utiliza para diseñar una solución técnica antes de escribir código.

## Pasos
1. **Investigar:** Recopilar requerimientos (del usuario o de la guía técnica).
2. **Diseñar:** Crear un documento de especificación que incluya:
   - **Objetivo:** Qué se quiere lograr.
   - **Cambios en DB:** Migraciones necesarias.
   - **Cambios en Backend:** Endpoints, servicios, modelos.
   - **Cambios en Frontend:** UI/UX, componentes, hooks.
   - **Testing:** Plan de pruebas.
3. **Aprobar:** Esperar la confirmación del usuario.

## Output Esperado
Un archivo `SPEC.md` temporal o una respuesta detallada con la arquitectura propuesta.
