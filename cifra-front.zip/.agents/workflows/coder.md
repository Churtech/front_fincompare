# Workflow: Coder — Implementación Técnica

Este workflow se utiliza para ejecutar una especificación previamente aprobada.

## Pasos
1. **Planificar:** Desglosar la tarea en pasos pequeños y atómicos.
2. **Implementar:** Escribir el código siguiendo las Skills del proyecto.
3. **Validar:** Ejecutar tests o verificar manualmente los cambios.
4. **Refinar:** Ajustar según feedback o errores encontrados.

## Reglas
- Mantener consistencia con el estilo de código existente.
- No dejar código comentado ni logs innecesarios.
- Documentar funciones complejas.
