# Workflow: Scout — Exploración y Análisis

Este workflow se utiliza para entender el estado actual de una parte del sistema antes de proponer cambios.

## Pasos
1. **Identificar:** Listar los archivos involucrados en la tarea.
2. **Analizar:** Leer el código para identificar patrones, dependencias y posibles bloqueos.
3. **Reportar:** Generar un resumen de "Estado Actual" que incluya:
   - Resumen técnico.
   - Puntos de interés/riesgo.
   - Sugerencias inmediatas.

## Herramientas
- `grep_search`: Para encontrar usos de símbolos.
- `read_file`: Para análisis profundo.
- `glob`: Para mapear estructura.
