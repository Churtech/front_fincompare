# Workflow: Reviewer — Control de Calidad

Este workflow se utiliza para validar cambios realizados y asegurar que cumplen con los estándares.

## Pasos
1. **Checklist de Skills:**
   - ¿Cumple con `skill-finance`? (Cálculos correctos).
   - ¿Cumple con `skill-backend` / `skill-frontend`? (Arquitectura y patrones).
   - ¿Maneja errores correctamente (`skill-errors`)?
2. **Análisis de Impacto:** ¿Afecta a otras partes del sistema?
3. **Sugerencias:** Listar mejoras de performance o legibilidad.

## Herramientas
- `lint` / `tsc`: Comprobar tipos y errores estáticos.
- `grep_search`: Verificar que no se rompieron referencias.
