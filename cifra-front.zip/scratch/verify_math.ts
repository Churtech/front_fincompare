import { deflateValue, calculateCDTTrajectoryDetailed } from '../src/views/ScenarioSimulator.tsx';

// Simple assertion helper
function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`❌ FAIL: ${message}`);
    process.exit(1);
  }
}

function assertNear(actual: number, expected: number, tolerance: number, message: string) {
  const diff = Math.abs(actual - expected);
  if (diff > tolerance) {
    console.error(`❌ FAIL: ${message} | Expected: ${expected}, Got: ${actual} (diff: ${diff}, tolerance: ${tolerance})`);
    process.exit(1);
  }
}

console.log('--------------------------------------------------');
console.log('🧪 Starting Scenario Simulator Math & Logic Verification');
console.log('--------------------------------------------------');

// ==========================================
// 1. Validate Fisher Deflation Utility
// ==========================================
console.log('🔹 Testing Fisher Deflation Math...');
{
  // V_real,t = V_nominal,t / (1 + i)^(t/12)
  // Scenario 1: No inflation (0%) -> Real value must equal Nominal value
  const nominal1 = 1000000;
  const real1 = deflateValue(nominal1, 12, 0);
  assert(real1 === nominal1, 'Fisher: 0% inflation should keep nominal and real identical');

  // Scenario 2: COP inflation (5.68%) at month 12
  // V_real,12 = 1,000,000 / (1 + 0.0568)^1 = 946,252.84
  const realCOP12 = deflateValue(1000000, 12, 5.68);
  assertNear(realCOP12, 946252.84, 0.01, 'Fisher: COP inflation at 12 months');

  // Scenario 3: USD inflation (2.0%) at month 24
  // V_real,24 = 1,500 / (1 + 0.02)^2 = 1441.75
  const realUSD24 = deflateValue(1500, 24, 2.0);
  assertNear(realUSD24, 1441.75, 0.01, 'Fisher: USD inflation at 24 months');

  console.log('✅ Fisher Deflation tests passed.');
}

// ==========================================
// 2. Validate CDT Compounding & 7% Tax
// ==========================================
console.log('\n🔹 Testing CDT Compounding and Withholding Tax...');
{
  // Test case: PV = 10,000,000 COP, PMT = 0, Rate = 10% EA, Years = 1, Inflation = 5.68%
  // Monthly rate: (1.10)^(1/12) - 1 = 0.0079741404
  // Months 1 to 11: compound monthly
  // Month 12: compound interest, then subtract 7% withholding tax from the accumulated interest of the year.
  const pv = 10000000;
  const pmt = 0;
  const rateEA = 10;
  const years = 1;
  const inflation = 5.68;

  const result = calculateCDTTrajectoryDetailed(pv, pmt, rateEA, years, inflation, false);

  // Let's compute expected manually:
  const monthlyRate = Math.pow(1 + rateEA / 100, 1 / 12) - 1;
  let balance = pv;
  let accumulatedInterestYear = 0;
  for (let m = 1; m <= 11; m++) {
    const interest = balance * monthlyRate;
    accumulatedInterestYear += interest;
    balance += interest;
  }
  // Month 11 balance should have NO withholding tax deducted yet
  assertNear(result.trajectory[11].nominal_value, balance, 0.01, 'CDT: Month 11 nominal balance does not contain withholding tax');

  // Month 12 calculation:
  const interest12 = balance * monthlyRate;
  accumulatedInterestYear += interest12;
  balance += interest12;
  const tax = accumulatedInterestYear * 0.07;
  const finalExpectedNominal = balance - tax;

  assertNear(result.finalNominalValue, finalExpectedNominal, 0.01, 'CDT: Final nominal value matches manual 12-month calculation');
  assertNear(result.totalTaxesDeducted, tax, 0.01, 'CDT: Total withholding tax matches expectation');

  // Check real value at month 12:
  const finalExpectedReal = finalExpectedNominal / (1 + inflation / 100);
  assertNear(result.finalRealValue, finalExpectedReal, 0.01, 'CDT: Final real value matches expected deflated value');

  console.log('✅ CDT Compounding and Tax tests passed.');
}

// ==========================================
// 3. Validate TRM Currency Conversion Logic
// ==========================================
console.log('\n🔹 Testing TRM Currency Conversion Logic...');
{
  const trm = 4000; // 4,000 COP/USD reference rate
  
  // Simulated handleCurrencyChange behavior:
  // COP to USD: val / trm rounded
  // USD to COP: val * trm rounded
  const initialCOP = 4000000;
  const initialUSD = Math.round(initialCOP / trm);
  assert(initialUSD === 1000, `TRM: COP -> USD conversion. Expected: 1000, Got: ${initialUSD}`);

  const contributionUSD = 125;
  const contributionCOP = Math.round(contributionUSD * trm);
  assert(contributionCOP === 500000, `TRM: USD -> COP conversion. Expected: 500000, Got: ${contributionCOP}`);

  console.log('✅ TRM Currency Conversion tests passed.');
}

// ==========================================
// 4. Validate Debounce Logic behavior
// ==========================================
console.log('\n🔹 Testing Input Debounce Timing...');
{
  // Since we cannot run standard react hooks directly inside terminal without full DOM environment,
  // we will test the logic of the debounce timer itself via a Mock Debouncer implementation
  // matching the hook in ScenarioSimulator.tsx:
  //
  // function useDebounce<T>(value: T, delay: number): T {
  //   const [debouncedValue, setDebouncedValue] = useState<T>(value);
  //   useEffect(() => {
  //     const handler = setTimeout(() => { setDebouncedValue(value); }, delay);
  //     return () => { clearTimeout(handler); };
  //   }, [value, delay]);
  //   return debouncedValue;
  // }

  const delay = 300;
  let timerId: any = null;
  let debouncedVal = 'initial';

  function mockSetInput(newValue: string) {
    if (timerId) {
      clearTimeout(timerId);
    }
    timerId = setTimeout(() => {
      debouncedVal = newValue;
    }, delay);
  }

  // Simulate typing 'abc' rapidly:
  mockSetInput('a');
  mockSetInput('ab');
  mockSetInput('abc');

  // Verify it has not updated immediately
  assert(debouncedVal === 'initial', 'Debounce: Value should not update immediately');

  // Wait 150ms (before delay)
  setTimeout(() => {
    assert(debouncedVal === 'initial', 'Debounce: Value should still be initial at 150ms');
  }, 150);

  // Wait 350ms (after delay)
  setTimeout(() => {
    assert(debouncedVal === 'abc', `Debounce: Value should be updated to 'abc' after 350ms. Got: ${debouncedVal}`);
    console.log('✅ Input Debounce tests passed.');
    console.log('\n⭐ ALL TESTS PASSED SUCCESSFULLY! ⭐');
    process.exit(0);
  }, 350);
}
