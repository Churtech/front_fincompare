# FinCompare — Project Steering

Este archivo contiene las directrices fundamentales para el desarrollo de FinCompare. El agente debe seguir estas reglas en todo momento.

## 1. Visión y Estilo
- **Producto:** Comparador institucional de activos financieros en Colombia.
- **Estilo Visual:** "Institutional Intelligence Terminal". Limpio, tipografía serif para títulos (serif headings), alto contraste, tonos slate/emerald/primary.
- **Target:** Inversionista colombiano (datos en COP, cálculos de retención en la fuente).

## 2. Stack Tecnológico
- **Frontend:** React 19 + TypeScript + Vite + Tailwind CSS 4.
- **Backend:** Go 1.22+ (Gin Gonic).
- **Base de Datos:** PostgreSQL (pgx driver).
- **Visualización:** ECharts (preferido para gráficos complejos) y Recharts.
- **Estado Global:** React Query (TanStack Query).

## 3. Arquitectura y Convenciones
- **Backend:** Clean Architecture / Hexagonal.
  - `internal/domain`: Entidades y reglas de negocio.
  - `internal/port`: Interfaces (Inbound/Outbound).
  - `internal/adapter`: Implementaciones (REST, Postgres, Scrapers).
- **Frontend:** Componentes funcionales, hooks personalizados para lógica de datos, arquitectura de carpetas por `views`, `components`, `hooks`, `lib`.
- **Errores:** Seguir patrones de `skill-errors`. Mensajes claros y tipados.
- **Testing:** Unit tests para lógica financiera (yields, taxes).

## 4. Workflows Disponibles
- `/scout`: Analizar el estado actual de un componente o servicio.
- `/spec-writer`: Diseñar cambios arquitectónicos o nuevas features.
- `/coder`: Implementar código basado en una spec aprobada.
- `/reviewer`: Revisar calidad de código y adherencia a skills.

## 5. Skills Críticas
- `skill-finance`: Lógica de negocios financiera (CDT, TRM, ETFs).
- `skill-scraping`: Técnicas de extracción de datos (Colly/Rod).
- `skill-backend`: Patrones Go y PostgreSQL.
- `skill-frontend`: Patrones React y UI/UX.

---
*FinCompare · 2026*
