# Exploración y Auditoría del Frontend (Cifra)

Se ha realizado una auditoría completa del código fuente del proyecto React frontend ubicado en `cifra`, basándonos en los lineamientos técnicos, de negocio financiero y de errores proporcionados en las guías y el documento `FinCompare_Deuda_Tecnica_Plan_Mejoras.md`.

A continuación, se detallan los hallazgos categorizados por deuda técnica resuelta, bugs encontrados, deuda técnica pendiente y fallas arquitectónicas.

## 1. Estado de la Deuda Técnica (Según Plan Original)

*   **DT-1 (18 Hooks en el Dashboard):** ✅ **Resuelto.** El archivo `Dashboard.tsx` ya no hace múltiples llamadas concurrentes. Se implementó el uso del hook centralizado `useDashboardSummary` que interactúa con el BFF del backend (`/api/v1/dashboard/summary`).
*   **DT-4 (Tipado Incorrecto de Env Vars):** ✅ **Resuelto.** Se implementó correctamente en `vite-env.d.ts` y en `lib/api.ts` ya se lee la variable sin `as any`.
*   **DT-3 (Dependencia `express` en producción):** 🟡 **Parcialmente Resuelto.** El paquete `express` fue eliminado de `dependencies`, sin embargo, aún persiste un rastro residual de `@types/express` en las `devDependencies` de `package.json` que debería ser limpiado.
*   **DT-2 (`console.log` en bundle de producción):** 🟡 **Parcialmente Resuelto.** Se envolvió la gran mayoría de los logs de `useFinance.ts` dentro de condicionales `if (import.meta.env.DEV)`. No obstante, el plugin de Vite `vite-plugin-remove-console` recomendado **no fue instalado ni configurado** en `vite.config.ts`, lo que deja vulnerable a que otros `console.log` no envueltos sigan apareciendo en producción.

## 2. Bugs y Errores Detectados

*   **Fuga de Logs en AuthContext (Bug de Privacidad):** Existen `console.log` directos y `console.error` dentro de `src/context/AuthContext.tsx` que no fueron protegidos con la condicional del entorno (`import.meta.env.DEV`). Esto produce que cambios de estado de autenticación de Supabase se impriman en las DevTools del navegador en producción.
*   **Falta de Error Boundaries:** Incumpliendo explícitamente el estándar definido en `skill-errors.md`, ni `main.tsx` ni `App.tsx` envuelven la jerarquía de la aplicación o sus vistas principales con un `<ErrorBoundary>`. Si algún componente falla, toda la UI colapsará (pantalla en blanco) en lugar de atrapar la excepción y mostrar un mensaje controlado.

## 3. Fallas Arquitectónicas (Architectural Flaws)

*   **Mono-Componente Inmanejable (`Portfolios.tsx`):** El archivo `Portfolios.tsx` consta de **1486 líneas de código**. Engloba `BacktestModal`, `PortfolioInsights`, `PortfolioAnalysisDetails`, `PortfolioCard` y la vista principal de manera acoplada. Esto viola los principios de diseño atómico y separación de responsabilidades, encareciendo el mantenimiento y limitando la escalabilidad del código. Debería dividirse en componentes más pequeños.
*   **Routing Basado en Estado Local (Sin URLs Reales):** La navegación de la plataforma (`App.tsx`) se realiza mutando una variable de estado local (`currentView`), en lugar de utilizar un sistema de enrutamiento basado en el navegador (como `react-router-dom`). Esto impide el uso de los botones *Adelante/Atrás* del navegador, imposibilita el "Deep Linking" (compartir URLs que apunten directamente a un activo, portafolio o simulador) y perjudica la experiencia de usuario general.
*   **Falta de Code Splitting / Lazy Loading:** Tal y como advertía el plan original de mejoras, el sistema carga el 100% de los componentes al inicio. Al usar un estado simple (`currentView`) sin aplicar `React.lazy()` ni `Suspense` para las vistas principales, el bundle inicial es excesivamente pesado.

## Conclusión

El frontend está avanzando favorablemente en base al plan (sobre todo con la integración del BFF del dashboard y mejoras en TypeScript). Para escalar y blindar el producto al 100% antes de habilitar planes de monetización, el paso inmediato debe ser instalar el plugin eliminador de logs en Vite, empaquetar la app con *Error Boundaries*, refactorizar `Portfolios.tsx` y priorizar la implementación de un *router* oficial con carga perezosa (`lazy loading`).
