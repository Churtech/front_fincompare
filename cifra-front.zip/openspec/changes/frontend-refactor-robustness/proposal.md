# Proposal: Frontend Refactor Robustness

## Intent
Address findings from `audit-frontend` and user feedback by eliminating data leaks, introducing robust error handling, modularizing large components, and establishing a clean architecture with scalable routing.

## Scope
### In Scope
- Patch `AuthContext` data leak (remove explicit console logs and configure Vite to drop console output in production).
- Implement React Error Boundaries (widget-level and screen-level) with retry mechanisms and strict zero-fake-data policies.
- Refactor `Portfolios.tsx` (1480 lines) into smaller, logical sub-components: Summary, Charts, Asset Table, and Rebalancing.
- Implement React Router with lazy loading for route splitting.
- Define a clean architecture folder structure for components, pages, and context.

### Out of Scope
- Backend API changes.
- Storing application state in URLs.
- Altering Supabase authentication flows (Supabase RLS handles this securely).

## Capabilities
### New Capabilities
- Graceful UI degradation via Error Boundaries with retry actions.
- Lazy loading of route components, reducing initial bundle size.

### Modified Capabilities
- `Portfolios.tsx` logic redistributed across modular components.
- Console outputs stripped in production builds.

## Approach
1. **Security first**: Clean `AuthContext` logs and update `vite.config.ts` with `drop_console` for the production build.
2. **Routing & Architecture**: Integrate `react-router-dom`, establish lazy-loaded routes, and create a scalable directory structure.
3. **Error Boundaries**: Create a reusable `ErrorBoundary` component that accepts fallback UI and retry callbacks. Integrate it at the route level and around critical financial widgets. Ensure no default or fake fallback data is ever presented.
4. **Refactoring**: Split `Portfolios.tsx` into `PortfolioSummary`, `PortfolioCharts`, `PortfolioAssetTable`, and `PortfolioRebalancing`.

## Affected Areas
- `AuthContext`
- `Portfolios.tsx`
- `vite.config.ts`
- Application routing entry point (`App.tsx` or similar)
- General component folder structure

## Risks
- **Regressions**: Splitting a 1480-line file might introduce state-sharing bugs between new sub-components.
- **Silent failures**: Aggressive error boundary capture might hide errors from monitoring unless logged properly.

## Rollback Plan
Revert the target branch. Because no backend changes are involved, reverting the frontend commit will cleanly restore the previous monolithic structure and routing behavior.

## Dependencies
- `react-router-dom`
- Existing Supabase auth setup

## Success Criteria
- Production bundle contains no `console.log` statements.
- Failing widgets show a retry button and block interaction, never displaying fake financial data.
- `Portfolios.tsx` is significantly reduced in size and delegates to modular sub-components.
- Lazy loading splits the JS bundle by route.
