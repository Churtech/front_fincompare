# Tasks: Frontend Refactor Robustness

## Review Workload Forecast
Decision needed before apply: No
Chained PRs recommended: No
Chain strategy: size-exception
400-line budget risk: High
Delivery strategy: exception-ok (Single manual commit at the end, no intermediate git actions)

## Phase 1: Security & Build Configuration
- [x] 1.1 Remove explicit console logs from `AuthContext`.
- [x] 1.2 Update `vite.config.ts` to drop console output in production (`drop_console`).

## Phase 2: Error Boundaries
- [x] 2.1 Create reusable `ErrorBoundary` component with fallback UI and retry callbacks (strict zero-fake-data policy).
- [x] 2.2 Integrate `ErrorBoundary` at the route level and around critical financial widgets. Ensure errors are logged to the monitoring system if applicable.

## Phase 3: Routing & Architecture Setup
- [x] 3.1 Verify/Install `react-router-dom` dependency.
- [x] 3.2 Establish the clean architecture folder structure (e.g., `components/`, `pages/`, `context/`).
- [x] 3.3 Set up `react-router-dom` in the application entry point (`App.tsx`) using lazy loading for route splitting.

### Phase 4: Refactoring `Portfolios.tsx`
- [x] **4.1** Extract `PortfolioSummary` component from `Portfolios.tsx`.
- [x] **4.2** Extract `PortfolioCharts` component from `Portfolios.tsx`.
- [x] **4.3** Extract `PortfolioAssetTable` component from `Portfolios.tsx`.
- [x] **4.4** Extract `PortfolioRebalancing` component from `Portfolios.tsx`.
- [x] **4.5** Refactor `Portfolios.tsx` to compose the new sub-components., passing required state and props carefully to avoid state-sharing bugs.

## Phase 5: Verification
- [x] **5.1** Verify that the production build strips `console.log` statements.
- [x] **5.2** Validate ErrorBoundary correctly catches route-level errors with retry functionality.
- [x] **5.3** Ensure `Portfolios.tsx` extracted sub-components load properly.
- [x] **5.4** Test network requests for the split view bundle to ensure performance gain.ded routes correctly split the JS bundle.
