# Proposal: front_stage4_scenarios

## Intent
Implement the interactive Scenario Simulator (Stage 4) in the React frontend, allowing users to run Monte Carlo simulations (Conservative P10, Base P50, Optimista P90) for variable income and compare them against fixed income (CDTs), adjusting for inflation via Fisher and converting currencies via TRM.

## Scope
| In Scope | Out of Scope |
| :--- | :--- |
| **Two-Column Layout**: Left column for control sliders (PV, PMT, Years), right column for charts, statistics, and education. | Backend Monte Carlo engine changes or database schema modifications. |
| **Recharts Probabilistic Fan**: Shaded area between P10 and P90 with the P50 line highlighted. | Editing the existing `RetrospectiveSimulator.tsx` logic. |
| **Nominal vs. Real Toggle**: Recalculates trayectories using Fisher and displays a mathematical details card ("Caja de Cristal"). | Multi-user portfolio sharing or real-time trading features. |
| **Moneda (COP/USD) Toggle**: Switches entire simulation between COP and USD using the active TRM rate. | Custom historical price data ingestion. |
| **Sincronización Dual**: Sincronización de sliders e inputs numéricos. | |

## Capabilities
* **Interactive Projections**: Multi-scenario projections for Renta Variable vs. CDTs.
* **Currency Portability**: Complete conversion (including CDT inputs) between USD and COP.
* **Fisher Deflating Details**: Step-by-step math layout on inflation impact.

## Approach
1. **Routing**: Add 'scenarios' route to `src/App.tsx` and menu item in `src/components/Sidebar.tsx`.
2. **Component Creation**: Create `src/views/ScenarioSimulator.tsx` using Tailwind CSS and Recharts.
3. **Data Sync**: Sincronize sliders and text inputs using state handlers.
4. **Calculations**: Compound CDT returns locally (7% ReteFuente deducted annually) and project assets using Monte Carlo metrics from the backend.
5. **TRM Toggle**: Scale PV/PMT inputs and final trajectory values by TRM when toggling base currency.

## Affected Areas
* `src/App.tsx` (View switcher)
* `src/components/Sidebar.tsx` (Menu navigation)
* `src/views/ScenarioSimulator.tsx` (New view)

## Risks & Mitigations
* **Performance Lag**: High dataset size rendering in Recharts. *Mitigation*: Downsample trajectories to monthly intervals.
* **TRM conversion discrepancies**: Mismatches between frontend and backend TRM conversions. *Mitigation*: Share a utility library or use a single TRM source of truth from API hooks.

## Rollback Plan
Discard all uncommitted changes or revert the specific commit using git:
```bash
git checkout main
git branch -D change/front_stage4_scenarios
```

## Dependencies
* Backend simulation/assets endpoints.
* Tailwind CSS and Recharts library.

## Success Criteria
1. Recharts renders a shaded area (P10-P90) and a highlighted line (P50).
2. The COP/USD toggle converts all input and output fields accurately using TRM.
3. The Nominal/Real toggle updates the chart and reveals the Fisher explanation panel.
4. UI renders cleanly on mobile and desktop without layout overflows.
