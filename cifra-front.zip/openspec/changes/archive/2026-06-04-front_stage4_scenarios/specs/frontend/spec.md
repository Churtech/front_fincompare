# Spec: front_stage4_scenarios - Frontend Behavioral Specifications

This delta specification defines the behavior of the Scenario Simulator (Stage 4) frontend view, specifically covering interactive projection inputs, currency toggle logic, and inflation-adjustment (Fisher) toggling.

---

## Requirement 1: Interactive Projection Inputs Sincronización
The system MUST synchronize the input sliders and their corresponding numeric text boxes in real-time, trigger simulation recalculations on change, and constrain values to acceptable ranges.

### Scenario: Slider input modification
* **Given** the Scenario Simulator view is rendered with initial default projection inputs
* **When** the user modifies the "Aporte Inicial" (PV) slider to a new value
* **Then** the corresponding "Aporte Inicial" text box MUST update immediately to match the slider's value
* **And** the projection chart and statistics summary MUST update to reflect the recalculated simulation trajectories.

### Scenario: Numerical text box modification
* **Given** the Scenario Simulator view is rendered
* **When** the user inputs a valid number into the "Aporte Mensual" (PMT) text box
* **Then** the corresponding "Aporte Mensual" slider MUST immediately adjust its position to reflect the text box input
* **And** the projection chart and statistics summary MUST update to reflect the recalculated simulation trajectories.

---

## Requirement 2: Moneda (COP/USD) Toggle
The system MUST support toggling the active base currency between Colombian Pesos (COP) and United States Dollars (USD) using the active TRM (Tasa Representativa del Mercado) rate. All inputs, outputs, charts, and statistics MUST convert dynamically.

### Scenario: Toggling base currency from COP to USD
* **Given** the active currency is set to COP
* **And** the active TRM rate is 4,000 COP/USD
* **And** the "Aporte Inicial" (PV) input displays 4,000,000 COP
* **When** the user toggles the currency selector to "USD"
* **Then** the "Aporte Inicial" (PV) input value MUST change to display 1,000 USD
* **And** the Y-axis of the projection chart MUST display values scaled to USD
* **And** all metrics card values MUST display currency indicators in USD.

### Scenario: Toggling base currency from USD to COP
* **Given** the active currency is set to USD
* **And** the active TRM rate is 4,000 COP/USD
* **And** the "Aporte Inicial" (PV) input displays 1,500 USD
* **When** the user toggles the currency selector to "COP"
* **Then** the "Aporte Inicial" (PV) input value MUST change to display 6,000,000 COP
* **And** the Y-axis of the projection chart MUST display values scaled to COP
* **And** all metrics card values MUST display currency indicators in COP.

---

## Requirement 3: Nominal vs. Real (Fisher) Toggling
The system MUST support toggling the projection calculation mode between Nominal (unadjusted) and Real (inflation-adjusted) values. Real value calculations MUST utilize the Fisher equation to deflate projected returns and display an educational glass-box math details panel.

### Scenario: Toggling to Real (Inflation-Adjusted) projections
* **Given** the simulation projection mode is set to "Nominal"
* **And** the mathematical details panel ("Caja de Cristal") is hidden
* **When** the user toggles the projection mode to "Real"
* **Then** the chart trajectories for fixed and variable income MUST be recalculated and rendered using inflation-deflated rates calculated via the Fisher equation
* **And** the mathematical details panel ("Caja de Cristal") MUST become visible, presenting the step-by-step mathematical calculation.

### Scenario: Toggling back to Nominal projections
* **Given** the simulation projection mode is set to "Real"
* **And** the mathematical details panel is visible
* **When** the user toggles the projection mode to "Nominal"
* **Then** the chart trajectories MUST be recalculated and rendered using nominal returns
* **And** the mathematical details panel ("Caja de Cristal") MUST be hidden.
