# Tasks: Interactive Scenario Simulator (`front_stage4_scenarios`)

## Review Workload Forecast

| Field | Value |
|-------|-------|
| Estimated changed lines | 550 |
| 400-line budget risk | High |
| Chained PRs recommended | Yes |
| Suggested split | PR1: Foundation & Routing; PR2: Simulator Component & Math; PR3: Tests |
| Delivery strategy | ask-on-risk |
| Chain strategy | stacked-to-main |

Decision needed before apply: Yes
Chained PRs recommended: Yes
Chain strategy: stacked-to-main
400-line budget risk: High

### Suggested Work Units
| Unit | Goal | Likely PR | Notes |
|------|------|-----------|-------|
| Unit 1 | Add types, hook params, and register new route & sidebar menu link | PR #1 | Core integration & navigation foundations |
| Unit 2 | Implement ScenarioSimulator view component and compounding/Fisher maths | PR #2 | Primary UI & simulation engine |
| Unit 3 | Add unit/integration tests to verify math formulas and slider behaviors | PR #3 | Quality assurance validation |

## Phase 1: Foundation / Infrastructure
- [x] 1.1 Update `src/types.ts` to add `ScenarioTrajectoryPoint`, `Scenario` interfaces, and extend `TechnicalAnalysis` with `scenarios`.
- [x] 1.2 Update `src/hooks/useFinance.ts` to extend `useAssetAnalysis` parameters with `initial_amount`, `monthly_contribution`, and `projection_years`.

## Phase 2: Router & Sidebar Integration
- [x] 2.1 Update `src/App.tsx` to import `ScenarioSimulator` and register the `scenarios` case in the view switcher router.
- [x] 2.2 Update `src/components/Sidebar.tsx` to register the navigation menu button for `"scenarios"` (Label: `"Simulador de Escenarios"`, Icon: `TrendingUp`).

## Phase 3: Simulator View Component
- [x] 3.1 Create `src/views/ScenarioSimulator.tsx` using a two-column desktop layout (inputs on left, charts and details on right).
- [x] 3.2 Implement numeric input and slider dual synchronization for initial amount, monthly contributions, and projection years.
- [x] 3.3 Add `300ms` debounce logic for inputs before calling the `useAssetAnalysis` query.
- [x] 3.4 Implement client-side monthly CDT compounding logic with annual 7% withholding tax deduction (`Retención en la Fuente`) in month 12/24/etc.
- [x] 3.5 Implement Fisher equation deflation utility for Real returns using 5.68% annual inflation for COP and 2.0% for USD.
- [x] 3.6 Integrate Recharts `<AreaChart>` using `<Area>` for P10-P90 range and `<Line>` for P50 and CDT trajectories.
- [x] 3.7 Implement COP/USD TRM currency converter for all inputs, outputs, and chart values using `useTRMMetrics`.
- [x] 3.8 Build the "Caja de Cristal" math drawer panel displaying equations, references, assumptions, and disclaimers.

## Phase 4: Testing & Verification
- [x] 4.1 Create test suite (e.g. `src/__tests__/ScenarioSimulator.test.tsx` or inline helpers) validating CDT compounding and Fisher deflation calculations.
- [x] 4.2 Validate inputs synchronization, debounce timer behavior, and active currency conversions using mock rates.
