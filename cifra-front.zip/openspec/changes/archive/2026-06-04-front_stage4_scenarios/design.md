# Technical Design: Interactive Scenario Simulator (`front_stage4_scenarios`)

This document outlines the architecture, data flow, and file changes to implement the interactive Scenario Simulator (Stage 4) in the React frontend.

---

## 1. Technical Approach
The Scenario Simulator provides users with interactive Monte Carlo projections (P10, P50, P90) for variable income assets and compares them against locally compounded fixed income (CDT) rates.

```
+-------------------------------------------------------------+
| View: ScenarioSimulator.tsx                                 |
|                                                             |
|  +-----------------------+   +---------------------------+  |
|  | Sliders & Inputs (PV, |   | Recharts Area Chart       |  |
|  | PMT, Years, Ticker)   |   | (P10-P90 Area, P50, CDT)  |  |
|  +-----------+-----------+   +-------------+-------------+  |
|              |                             |                |
|      (Debounced params)            (COP/USD & Real/Nominal) |
|              v                             v                |
|      useAssetAnalysis()            Fisher & TRM Utilities   |
+--------------+-----------------------------+----------------+
               | (HTTP GET)
               v
     [/assets/:ticker/analysis]
```

Key features:
* **Slider-Input Sync**: Instant local state synchronization with a `300ms` debounced query parameter update to prevent API rate-limiting during slider drag.
* **CDT Compounding**: Client-side CDT compounding at a monthly frequency. Deducts a **7% withholding tax** (`Retención en la Fuente`) on interest accrued at the end of each 12-month cycle.
* **Fisher Deflation**: When "Real" is toggled, converts nominal values to real values using:
  $$V_{real, t} = \frac{V_{nominal, t}}{(1 + i)^{t/12}}$$
  where $i$ is the annual inflation rate (COP: 5.68%, USD: 2.0%) and $t$ is the month index.
* **TRM Currency Conversion**: Toggles all inputs, chart axis values, and metrics between COP and USD using the active TRM rate.

---

## 2. Architecture Decisions

### Decision 1: Client-Side CDT Compounding
* **Alternative**: Add a backend endpoint for CDT simulation.
* **Rationale**: CDT calculations are deterministic and computationally trivial. Compounding client-side using reference rates (`useBestCDT` / `/metrics`) avoids extra backend roundtrips, ensuring zero-latency updates when adjusting inputs.

### Decision 2: Recharts `<Area>` + `<Line>` for Probabilistic Fan
* **Alternative**: Render three distinct line graphs.
* **Rationale**: Fenced areas are standard for displaying confidence intervals (P10 to P90). It prevents visual clutter and clearly separates variable risk bounds from the deterministic CDT line.

### Decision 3: 300ms Query Param Debouncing
* **Alternative**: Execute API calls on every slider value change.
* **Rationale**: Slider adjustments trigger dozens of state changes per second. Debouncing requests by `300ms` maintains UI responsiveness while keeping backend request traffic low.

---

## 3. Interfaces & Contracts

### 3.1 Type Definitions (`src/types.ts`)
```typescript
export interface ScenarioTrajectoryPoint {
  month: number;
  nominal_value: number;
  real_value: number;
}

export interface Scenario {
  name: string; // "Conservador", "Base", "Optimista"
  return_rate: number;
  real_return: number;
  trajectory: ScenarioTrajectoryPoint[];
}

// Extend TechnicalAnalysis in src/types.ts
export interface TechnicalAnalysis {
  scenarios?: Scenario[];
}
```

### 3.2 React Query Hook (`src/hooks/useFinance.ts`)
```typescript
export const useAssetAnalysis = (
  ticker: string, 
  params?: { 
    currency?: string; 
    lookback_days?: number; 
    initial_amount?: number; 
    monthly_contribution?: number; 
    projection_years?: number;
  }
) => {
  return useQuery({
    queryKey: ['assets', ticker, 'analysis', params],
    queryFn: async () => {
      const { data } = await api.get<AnalysisReport>(`/assets/${ticker}/analysis`, { params });
      return data;
    },
    enabled: !!ticker,
  });
};
```

---

## 4. File Changes

### `src/types.ts`
* Add `ScenarioTrajectoryPoint` and `Scenario` interfaces.
* Update `TechnicalAnalysis` to include optional `scenarios?: Scenario[]`.

### `src/hooks/useFinance.ts`
* Update `useAssetAnalysis` definition to accept `initial_amount`, `monthly_contribution`, and `projection_years` in its query params.

### `src/App.tsx`
* Import `ScenarioSimulator` from `./views/ScenarioSimulator`.
* Add `scenarios` view state handler inside the route switcher.

### `src/components/Sidebar.tsx`
* Register navigation link for `"scenarios"` (Label: `"Simulador de Escenarios"`, Icon: `TrendingUp`).

### `src/views/ScenarioSimulator.tsx` (New View)
* Build the simulator UI with a two-column layout (Controls vs. Chart/Insights).
* Implement the custom React hook for slider/textbox synchronization and state debouncing.
* Render Recharts with `<AreaChart>` using `<Area>` for P10-P90 and `<Line>` for P50 and CDT trajectories.
* Add Nominal/Real and USD/COP toggle elements.
* Display the "Caja de Cristal" math drawer explaining inflation (Fisher) and CDT tax rules.

---

## 5. Testing & Verification
* **Unit Tests**: Add tests verifying local CDT compounding math (applying 7% withholding tax only on the 12th, 24th, etc., months) and the Fisher equation rate deflator.
* **UI Integration**: Verify that sliders and numeric input boxes stay synchronized and that the slider debounce triggers query invalidations only after 300ms.
